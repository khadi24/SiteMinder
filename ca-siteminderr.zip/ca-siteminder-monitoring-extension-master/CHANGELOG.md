# AppDynamics Extensions CA Siteminder CHANGELOG

## 2.0.3 - Jan 11, 2022
Updated log4j dependency from log4j-core 2.17.0 to log4j-core 2.17.1

## 2.0.2 - Dec 21, 2021
Updated log4j dependency from log4j-core 2.16.0 to log4j-core 2.17.0

## 2.0.1 - Dec 16, 2021
Updated log4j dependency from 1.2.17 to log4j-core 2.16.0

## 2.0.0 - Aug 20, 2021
Updated commons to 2.2.4