/*
 * Copyright 2018. AppDynamics LLC and its affiliates.
 * All Rights Reserved.
 * This is unpublished proprietary source code of AppDynamics LLC and its affiliates.
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 *
 */

package org.snmp4j.smi;

/**
 * The <code>MaxAccess</code> enumerates the MAX-ACCESS values of SMIv2 and the deprecated {@link #writeOnly}
 * of SMIv1.
 *
 * @author Frank Fock
 * @since 2.5.0
 */
public enum MaxAccess {

  notAccessible("not-accessible"),
  accessibleForNotify("accessible-for-notify"),
  writeOnly("write-only"),
  readOnly("read-only"),
  readWrite("read-write"),
  readCreate("read-create");

  private String smiValue;

  private MaxAccess(String smiValue) {
    this.smiValue = smiValue;
  }

  /**
   * Gets the MAX-ACCESS (or ACCESS in SMIv1) clause string.
   * @return
   *    the SMI access string.
   */
  public String getSmiValue() {
    return smiValue;
  }

  /**
   * Gets the {@link MaxAccess} from a MAX-ACCESS (or ACCESS in SMIv1) clause string.
   * @param smiValue
   *    the SMI access string.
   * @return
   *    <code>null</code> if <code>smiValue</code> is not a valid ACCESS/MAX-ACCESS clause value or
   *    the matching enumeration value.
   */
  public static MaxAccess fromSmiValue(String smiValue) {
    for (MaxAccess v : values()) {
      if (v.getSmiValue().equals(smiValue)) {
        return v;
      }
    }
    return null;
  }

  /**
   * Checks if the maximum access is {@link #readOnly}.
   * @return
   *    <code>true</code> if this maximum access equals {@link #readOnly}.
   */
  public boolean isReadOnly() {
    return this == readOnly;
  }

  /**
   * Checks if the maximum access is writable.
   * @return
   *    <code>true</code> if this maximum access equals {@link #readWrite} or {@link #readCreate}.
   */
  public boolean isWritable() {
    return ordinal() >= readWrite.ordinal();
  }

  /**
   * Checks if the maximum access is creatable.
   * @return
   *    <code>true</code> if this maximum access equals {@link #readCreate}.
   */
  public boolean isCreatable() {
    return this == readCreate;
  }

}
