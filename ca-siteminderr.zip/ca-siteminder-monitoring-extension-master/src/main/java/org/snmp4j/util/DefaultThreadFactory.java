/*
 * Copyright 2018. AppDynamics LLC and its affiliates.
 * All Rights Reserved.
 * This is unpublished proprietary source code of AppDynamics LLC and its affiliates.
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 *
 */
package org.snmp4j.util;

import org.snmp4j.SNMP4JSettings;

/**
 * The <code>DefaultThreadFactory</code> creates {@link WorkerTask} instances
 * that allow concurrent execution of tasks. By default it uses a timeout
 * of 60 seconds (1 min.) when joining threads on behalf of an call of the
 * {@link WorkerTask#join()} method. By setting
 *
 * @author Frank Fock
 * @version 1.10.2
 * @since 1.8
 */
public class DefaultThreadFactory implements ThreadFactory {

  private long joinTimeout;

  public DefaultThreadFactory() {
    joinTimeout = SNMP4JSettings.getThreadJoinTimeout();
  }

  /**
   * Creates a new thread of execution for the supplied task.
   *
   * @param name the name of the execution thread.
   * @param task the task to be executed in the new thread.
   * @return the <code>WorkerTask</code> wrapper to control start and
   *   termination of the thread.
   */
  public WorkerTask createWorkerThread(String name, WorkerTask task,
                                       boolean daemon) {
    WorkerThread wt = new WorkerThread(name, task);
    wt.thread.setDaemon(daemon);
    return wt;
  }

  /**
   * Sets the maximum time to wait when joining a worker task thread.
   * @param millis
   *    the time to wait. 0 waits forever.
   * @since 1.10.2
   */
  public void setThreadJoinTimeout(long millis) {
    this.joinTimeout = millis;
  }

  public class WorkerThread implements WorkerTask {

    private Thread thread;
    private WorkerTask task;
    private boolean started = false;

    public WorkerThread(String name, WorkerTask task) {
      this.thread = new Thread(task, name);
      this.task = task;
    }

    public void terminate() {
      task.terminate();
    }

    public void join() throws InterruptedException {
      task.join();
      thread.join(joinTimeout);
    }

    public void run() {
      if (!started) {
        started = true;
        thread.start();
      }
      else {
        thread.run();
      }
    }

    public void interrupt() {
      task.interrupt();
      thread.interrupt();
    }
  }
}
